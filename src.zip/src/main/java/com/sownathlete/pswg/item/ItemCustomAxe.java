package com.sownathlete.pswg.item;

import net.minecraft.item.ItemAxe;
import net.minecraft.item.Item.ToolMaterial;

public class ItemCustomAxe extends ItemAxe {
    public ItemCustomAxe(ToolMaterial material) {
        super(material);
    }
}
