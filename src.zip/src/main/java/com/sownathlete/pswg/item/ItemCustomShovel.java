package com.sownathlete.pswg.item;

import net.minecraft.item.ItemSpade;
import net.minecraft.item.Item.ToolMaterial;

public class ItemCustomShovel extends ItemSpade {
    public ItemCustomShovel(ToolMaterial material) {
        super(material);
    }
}
