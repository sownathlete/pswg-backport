package com.sownathlete.pswg.item;

import net.minecraft.item.ItemHoe;
import net.minecraft.item.Item.ToolMaterial;

public class ItemCustomHoe extends ItemHoe {
    public ItemCustomHoe(ToolMaterial material) {
        super(material);
    }
}
