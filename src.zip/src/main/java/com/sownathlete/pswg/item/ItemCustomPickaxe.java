package com.sownathlete.pswg.item;

import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.Item.ToolMaterial;

public class ItemCustomPickaxe extends ItemPickaxe {
    public ItemCustomPickaxe(ToolMaterial material) {
        super(material);
    }
}