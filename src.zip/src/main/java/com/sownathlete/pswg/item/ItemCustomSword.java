package com.sownathlete.pswg.item;

import net.minecraft.item.ItemSword;
import net.minecraft.item.Item.ToolMaterial;

public class ItemCustomSword extends ItemSword {
    public ItemCustomSword(ToolMaterial material) {
        super(material);
    }
}
