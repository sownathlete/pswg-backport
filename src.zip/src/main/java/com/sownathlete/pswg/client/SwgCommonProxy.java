/*
 * Decompiled with CFR 0.148.
 *
 * Could not load the following classes:
 *  net.minecraftforge.event.entity.player.PlayerPickupXpEvent
 */
package com.sownathlete.pswg.client;

import net.minecraftforge.event.entity.player.PlayerPickupXpEvent;

public class SwgCommonProxy {

    public void doSidedThings() {
    }

    public void onPreload() {
    }

    public void registerRendering() {
    }

    public void showJediSithGui(PlayerPickupXpEvent event) {
    }
}

