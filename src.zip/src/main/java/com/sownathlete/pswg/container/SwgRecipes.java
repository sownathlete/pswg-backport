package com.sownathlete.pswg.container;


import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class SwgRecipes {
    public static void registerAll() {
        registerShapedRecipes();
        registerSmeltingRecipes();
        registerShapelessRecipes();
    }

    // Shaped recipes
    private static void registerShapedRecipes() {
    }

    // Smelting recipes
    private static void registerSmeltingRecipes() {
    }

    // Shapeless recipes
    private static void registerShapelessRecipes() {
    }
}