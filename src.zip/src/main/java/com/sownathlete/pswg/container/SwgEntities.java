package com.sownathlete.pswg.container;

public class SwgEntities {
    public static void register() {
    }
}

